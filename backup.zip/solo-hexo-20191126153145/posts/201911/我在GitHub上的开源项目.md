title: 我在 GitHub 上的开源项目
date: '2019-11-24 20:46:56'
updated: '2019-11-24 20:46:56'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [DexEncryptionDecryption](https://github.com/yangkun19921001/DexEncryptionDecryption) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/yangkun19921001/DexEncryptionDecryption/watchers "关注数")&nbsp;&nbsp;[⭐️`47`](https://github.com/yangkun19921001/DexEncryptionDecryption/stargazers "收藏数")&nbsp;&nbsp;[🖖`8`](https://github.com/yangkun19921001/DexEncryptionDecryption/network/members "分叉数")</span>

APK 加固  dex 加密，解密



---

### 2. [KeepAlive](https://github.com/yangkun19921001/KeepAlive) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/yangkun19921001/KeepAlive/watchers "关注数")&nbsp;&nbsp;[⭐️`22`](https://github.com/yangkun19921001/KeepAlive/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/yangkun19921001/KeepAlive/network/members "分叉数")</span>

进程保活方案



---

### 3. [YKProBus](https://github.com/yangkun19921001/YKProBus) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/YKProBus/watchers "关注数")&nbsp;&nbsp;[⭐️`18`](https://github.com/yangkun19921001/YKProBus/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yangkun19921001/YKProBus/network/members "分叉数")</span>

轻量级进程间通信框架，基于 Messenger 实现。进程间传递数据不错的选择



---

### 4. [long_picture_view](https://github.com/yangkun19921001/long_picture_view) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/long_picture_view/watchers "关注数")&nbsp;&nbsp;[⭐️`16`](https://github.com/yangkun19921001/long_picture_view/stargazers "收藏数")&nbsp;&nbsp;[🖖`3`](https://github.com/yangkun19921001/long_picture_view/network/members "分叉数")</span>

加载 长图控件，仿微博加载方式



---

### 5. [LIBJPEG_SAMPLE](https://github.com/yangkun19921001/LIBJPEG_SAMPLE) <kbd title="主要编程语言">C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/LIBJPEG_SAMPLE/watchers "关注数")&nbsp;&nbsp;[⭐️`15`](https://github.com/yangkun19921001/LIBJPEG_SAMPLE/stargazers "收藏数")&nbsp;&nbsp;[🖖`6`](https://github.com/yangkun19921001/LIBJPEG_SAMPLE/network/members "分叉数")</span>

 JEPGLIB 图片压缩，哈夫曼算法图片压缩



---

### 6. [Kotlin_GitHub](https://github.com/yangkun19921001/Kotlin_GitHub) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/Kotlin_GitHub/watchers "关注数")&nbsp;&nbsp;[⭐️`13`](https://github.com/yangkun19921001/Kotlin_GitHub/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yangkun19921001/Kotlin_GitHub/network/members "分叉数")</span>

基于 Kotlin + MVP + retrofit + Okhttp +RxJava + Glide + anko + sw 限定符做了屏幕适配 等框架编写的 GitHub APP ，仅供学习



---

### 7. [YKCrash](https://github.com/yangkun19921001/YKCrash) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/yangkun19921001/YKCrash/watchers "关注数")&nbsp;&nbsp;[⭐️`11`](https://github.com/yangkun19921001/YKCrash/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/yangkun19921001/YKCrash/network/members "分叉数")</span>

Android 崩溃捕获(Java,native)



---

### 8. [YKComponent](https://github.com/yangkun19921001/YKComponent) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/YKComponent/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/yangkun19921001/YKComponent/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yangkun19921001/YKComponent/network/members "分叉数")</span>

Android 组件化框架探索



---

### 9. [Schema_Learning_Records](https://github.com/yangkun19921001/Schema_Learning_Records) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/Schema_Learning_Records/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/yangkun19921001/Schema_Learning_Records/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/yangkun19921001/Schema_Learning_Records/network/members "分叉数")</span>

Android 面试，数据结构和算法 音视频 C/C++ 人工智能（openCV，Dlib）跨平台---学习记录



---

### 10. [ChatUI_Component](https://github.com/yangkun19921001/ChatUI_Component) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yangkun19921001/ChatUI_Component/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/yangkun19921001/ChatUI_Component/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/yangkun19921001/ChatUI_Component/network/members "分叉数")</span>

聊天输入框，列表，录像等框架

